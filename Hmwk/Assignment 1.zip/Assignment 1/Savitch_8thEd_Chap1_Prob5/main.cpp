/* 
 * File:   main.cpp
 * Author: Jeremy Bucher
 * Created on June 25, 2014, 1:44 PM
 */

//User Defined Libraries

//Global Constants

//Function Rototypes

//Execution Begins Here
#include <iostream>

using namespace std;

 int main () { 

    int A, B, C, D;
    A=5, B=22;
    C=A+B;
    D=A*B;
    cout <<"The first integer is:\n";
    cout <<A;
    cout <<"  \n";
    cout <<"The second integer is:\n";
    cout <<B;
    cout <<"  \n";
    cout <<"The sum of the two integers is:\n";
    cout <<C;
    cout <<"  \n";
    cout <<"The product of the two integers is:\n";
    cout <<D;
    cout <<"  \n";
    cout <<"This is the end of the program\n";
    return 0;
}
