/* 
 * File:   main.cpp
 * Author: Jeremy Bucher
 * Created on June 25, 2014, 9:15 PM
 */

//User Defined Libraries

//Global Constants

//Function Rototypes

//Execution Begins Here
#include <iostream>
using namespace std;

 int main () { 
    cout <<"************************************************************\n";
    cout <<"  \n";
    cout <<"  \n";
    cout <<"        C C C              S S S S             !!\n";
    cout <<"      C       C          S         S           !!\n";
    cout <<"     C                  S                      !!\n";
    cout <<"    C                  S                       !!\n";
    cout <<"    C                   S                      !!\n";
    cout <<"    C                     S S S S              !!\n";
    cout <<"     C                             S           !!\n";
    cout <<"      C                             S          !! \n";
    cout <<"       C      C          S         S           \n";
    cout <<"         C C C             S S S S             00\n";
    cout <<"  \n";
    cout <<"  \n";
    cout <<"************************************************************\n";
    cout <<"  \n";
    cout <<"            Computer Science is Cool Stuff!!!\n";

    return 0;
}
