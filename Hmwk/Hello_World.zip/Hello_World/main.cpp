/* 
 * File:   main.cpp
 * Author: Jeremy Bucher
 * Created on June 23, 2014, 9:23 PM
 * Purpose: First Program
 */

//System Level Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
//Output simple text
    cout <<"Hello World"<< endl;
    //Exit Stage right!
    return 0;
}

